# Legacy package definitions

This folder contains legacy `package.json` files with old namings, to trick Github into tracking dependents for them as well in the Insights section of the repository.


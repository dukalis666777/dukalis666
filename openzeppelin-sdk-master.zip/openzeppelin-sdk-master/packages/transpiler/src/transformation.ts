export interface Transformation {
  start: number;
  end: number;
  text: string;
}

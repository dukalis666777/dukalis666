module.exports = {
  ...require("../../.prettierrc.base.js"),
};

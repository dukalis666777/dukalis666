import path from 'path';

export const OPEN_ZEPPELIN_FOLDER = '.openzeppelin';
export const LOCK_FILE = '.lock';
export const LOCK_FILE_PATH = path.join(OPEN_ZEPPELIN_FOLDER, LOCK_FILE);

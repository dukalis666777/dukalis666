# mock-project-to-compile

This project is used to test that the following import styles are supported by the compiler:

```solidity
// contracts/subfolder/GreeterImpl.sol
import "contracts/subfolder/GreeterLib.sol";
import "./GreeterLib2.sol";
```

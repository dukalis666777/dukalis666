# mock-project-with-repeated-names

This project is used to test a project with more than one contract with the same name.
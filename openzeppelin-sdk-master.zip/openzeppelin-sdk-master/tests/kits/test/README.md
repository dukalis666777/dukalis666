# Starter kits integration test

Integration tests for Starter kits and an unpack command.
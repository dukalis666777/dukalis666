# CLI app integration test

Integration tests for a ZeppelinOS CLI app project.